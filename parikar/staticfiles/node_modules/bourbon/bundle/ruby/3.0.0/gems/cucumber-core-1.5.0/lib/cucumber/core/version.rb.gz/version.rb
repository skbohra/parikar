module Cucumber
  module Core
    class Version
      def self.to_s
        "1.5.0"
      end
    end
  end
end
