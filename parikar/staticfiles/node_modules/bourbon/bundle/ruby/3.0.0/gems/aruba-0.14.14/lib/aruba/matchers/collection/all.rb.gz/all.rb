require 'rspec/expectations'

# Aruba
module Aruba
  # Matchers
  module Matchers
    include ::RSpec::Matchers

    module_function :all
  end
end
