require 'aruba/platform'
Aruba.platform.deprecated('The use of "aruba/jruby" is deprecated. Use "aruba/config/jruby" instead')

require 'aruba/config/jruby'
