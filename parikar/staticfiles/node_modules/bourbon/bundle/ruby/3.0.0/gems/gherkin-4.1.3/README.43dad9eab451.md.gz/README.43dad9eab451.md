[![Build Status](https://secure.travis-ci.org/cucumber/gherkin-ruby.svg)](http://travis-ci.org/cucumber/gherkin-ruby)

Gherkin parser/compiler for Ruby. Please see [Gherkin](https://github.com/cucumber/gherkin) for details.

## Developers

Some files are generated from the `gherkin-ruby.razor` file. Please run the
following command to generate the ruby files.

~~~bash
cd <project_root>/ruby
make
~~~
