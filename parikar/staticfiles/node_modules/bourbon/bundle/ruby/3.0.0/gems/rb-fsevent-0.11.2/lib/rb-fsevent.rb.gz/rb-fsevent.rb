# -*- encoding: utf-8 -*-
require 'rb-fsevent/fsevent'
require 'rb-fsevent/version'
