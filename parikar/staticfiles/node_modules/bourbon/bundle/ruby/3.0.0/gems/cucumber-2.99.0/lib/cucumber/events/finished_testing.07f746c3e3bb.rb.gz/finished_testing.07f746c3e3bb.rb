module Cucumber
  module Events

    # Event fired after aall test cases have finished executing
    class FinishedTesting
    end

  end
end
