$(document).ready(function() {
  $('.filesystem .file').click(function() {
    $(this).find('.highlight').toggle(100);
  });
});