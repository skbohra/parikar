module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.12.2'
    end
  end
end
