#ifndef EXTCONF_H
#define EXTCONF_H
#define HAVE_FFI_PREP_CIF_VAR 1
#define USE_INTERNAL_LIBFFI 1
#endif
