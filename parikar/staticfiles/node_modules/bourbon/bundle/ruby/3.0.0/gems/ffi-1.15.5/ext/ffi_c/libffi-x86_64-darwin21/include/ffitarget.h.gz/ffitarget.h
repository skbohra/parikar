#if defined(__i386__)
#include "libffi-i386/include/ffitarget.h"
#elif defined(__x86_64__)
#include "libffi-x86_64/include/ffitarget.h"
#elif defined(__ppc__)
#include "libffi-ppc/include/ffitarget.h"
#endif
